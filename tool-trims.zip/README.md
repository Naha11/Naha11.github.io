# Tool Trims
This data pack adds 4 tool trim smithing templates that allows you to trim weapons and tools. For more information or to check for new updates, visit [the project page on Modrinth](https://modrinth.com/datapack/tool-trims).

<br>

## Credits
**Contributors**
- BlueSheep (Trimmable Tridents)

**Translators**
- BlueSheep (Japanese)
- ESSENTIALS_GAMES (Polish)
- RandomKuchen (German)
- Slimy (Ukrainian and Russian)

**Special Thanks**
- Coolsa, for the [Gui Generator](https://coolsa.github.io/mcCustomGuiGen/)
- ImpossibleEvan

<br>

## Copyrigh Notice
Copyright (C) 2023-2026 JoeFly. All rights reserved.