item replace block ~ ~ ~ container.0 with minecraft:air
item replace block ~ ~ ~ container.1 with minecraft:air
item replace block ~ ~ ~ container.2 with minecraft:air
item replace block ~ ~ ~ container.3 with minecraft:air
item replace block ~ ~ ~ container.4 with minecraft:air
item replace block ~ ~ ~ container.5 with minecraft:air
item replace block ~ ~ ~ container.6 with minecraft:air
item replace block ~ ~ ~ container.7 with minecraft:air
item replace block ~ ~ ~ container.8 with minecraft:air
item replace block ~ ~ ~ container.9 with minecraft:air
item replace block ~ ~ ~ container.10 with minecraft:air
item replace block ~ ~ ~ container.11 with minecraft:air
item replace block ~ ~ ~ container.12 with minecraft:air
item replace block ~ ~ ~ container.13 with minecraft:air
item replace block ~ ~ ~ container.14 with minecraft:air
item replace block ~ ~ ~ container.15 with minecraft:air
item replace block ~ ~ ~ container.16 with minecraft:air
item replace block ~ ~ ~ container.17 with minecraft:air
item replace block ~ ~ ~ container.18 with minecraft:air

item replace block ~ ~ ~ container.22 with minecraft:air
item replace block ~ ~ ~ container.23 with minecraft:air
item replace block ~ ~ ~ container.24 with minecraft:air
item replace block ~ ~ ~ container.25 with minecraft:air
item replace block ~ ~ ~ container.26 with minecraft:air

setblock ~ ~ ~ minecraft:air destroy
kill @n[type=minecraft:item, nbt={Item:{id:"minecraft:barrel"}}]
loot spawn ~ ~ ~ loot tooltrims:migration/toolsmithing_table_ingredients

kill @s