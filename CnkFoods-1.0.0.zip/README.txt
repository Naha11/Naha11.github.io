CnkFoods 1.0.0 — самостоятельный плагин-замена Crop & Kettle
==============================================================

ЧТО ВНУТРИ
- 175 предметов еды CnK (apple_pie, tomato, beef_wellington, ...)
- 19 декор-блоков с 3D-моделями из ресурспака:
    distiller, cooking_pot, stove, mixing_bowl, cutting_board,
    mr_kettle, basin, faucet, calendar, wine_rack, scarecrow,
    wreath, cornucopia, hollow_vessel, candy_bowl, plate, pail,
    gift_box, gift
- distiller-блок:
    * рецепт верстака (как в датапаке)
    * 3D-модель колонны через ItemDisplay
    * кастомный hopper-GUI с font cnk:gui
    * 18 рецептов напитков (water_bucket + ingredient)
- distiller_book ("Сборник пивовара"):
    * ПКМ — список 18 рецептов distiller'а в чате
- wine_rack:
    * CRAFTER-инвентарь 9 слотов
    * фильтр только cnk-вина (14 видов *_wine)
    * 6 бутылок рендерятся внутри полки как ItemDisplay
- 122 рецепта верстака (cooking_pot) — крафт через ваниль с PDC-проверкой
- Команды: /cnk give|list|reload (алиасы /crop, /kettle, /еда)
- БЕЗ зависимости от датапака, squaremap, Vault и др.

ТРЕБОВАНИЯ
- Paper / Purpur 1.21.11
- Java 21
- Ресурспак CnK (assets v1.2.10) — для текстур и font cnk:gui

УСТАНОВКА
1. cnk-foods-plugin-1.0.0.jar -> server/plugins/
2. Подключить ресурспак через server.properties:
     resource-pack=https://your-host/cnk-resourcepack.zip
     resource-pack-sha1=<sha1>
3. Перезапуск сервера

ВИЗУАЛЬНАЯ СХЕМА БЛОКОВ
- Носитель блока = HOPPER (большинство) или CRAFTER (wine_rack):
  даёт TileState с PDC и физическую коллизию.
- Поверх блока — ItemDisplay (Material.BARRIER) с item_model из ресурспака,
  scale 1.002, brightness 15/15, viewRange 2.0 — точная 3D-модель,
  не мерцает и не темнеет ночью.
- При ломании блока — display удаляется, выпадает оригинальный CnK-item.

КОМАНДЫ
  /cnk give <id> [count] [player]   — выдать предмет
  /cnk list [filter]                — показать каталог
  /cnk reload                       — перечитать YAML

ПРАВА
  cnk.use     — give/list (op)
  cnk.admin   — reload (op)

ОГРАНИЧЕНИЯ
  - Машины cutting_board / mixing_bowl / mr_kettle = пока чистый декор
  - Книги-индексы foodie_book / cookbook не добавлены
  - Растения и crop-system отсутствуют

АВТОРЫ
  Плагин: naha11
  Оригинал: Crop & Kettle team (v1.2.10)
