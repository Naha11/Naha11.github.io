summon minecraft:marker ~ ~ ~ {CustomName:{translate:tooltrims.title}, Tags:["tooltrims.assets_dectector"]}
execute unless entity @n[type=marker, tag=tooltrims.assets_dectector, name="Tool Trims"] run tellraw @a {text: "[Tool Trims] The required assets weren't detected. Make sure to copy the data pack to your \"resourcepacks\" folder and use it as a resourcepack.", color:"red" }

kill @n[type=marker, tag=tooltrims.assets_dectector]