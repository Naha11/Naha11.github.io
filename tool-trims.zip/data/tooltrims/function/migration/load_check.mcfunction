execute store success score $tooltrims.migration tooltrims.variable run scoreboard players set $tooltrims.migration 310_recipe 1
execute unless score $tooltrims.migration tooltrims.variable matches 1 store success score $tooltrims.migration tooltrims.variable run scoreboard players set $tooltrims.migration 310_operation 1
execute unless score $tooltrims.migration tooltrims.variable matches 1 store success score $tooltrims.migration tooltrims.variable run scoreboard players set $tooltrims.migration 310_count 1

execute if score $tooltrims.migration tooltrims.variable matches 1 run schedule function tooltrims:migration/load 2t